const loadData = () =>
  new Promise((resolve) => {
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = ({ target }) => {
      if (target.readyState == 4 && target.status == 200) {
        resolve(JSON.parse(target.response));
      }
    };
    xhttp.open("GET",`https://6253799f90266e3d0e0373e6.mockapi.io/ok/user`, true);
    xhttp.send();
  });

  const renderTable = (data, term) => {
    const tableBody = document.getElementById("table-main");
  
    if (!tableBody) {
      throw new Error("No table element found");
    }
  
    let source = data;
  
    if (term) {
  
      const valueTerm = document.getElementById('input-term').value.toLowerCase();
        switch(term) {
          case 'vin':      
              source = source.filter(({ vin }) => vin.toLowerCase().includes(valueTerm));            
              break;
          case 'manufacturer':
              source = source.filter(({ manufacturer}) => manufacturer.toLowerCase().includes(valueTerm));
              break;
          case 'model':
              source = source.filter(({ model }) => model.toLowerCase() === valueTerm);
              break;
          case 'type':
              source = source.filter(({ type }) => type.toLowerCase() === valueTerm);
              break;
          case 'age':
              source = source.filter(({ age }) => age.toLowerCase().includes(valueTerm));
              break; 
          case 'id':
              source = source.filter(({ id }) => id.toLowerCase().includes(valueTerm));
              break; 
          case 'userid':
              source = source.filter(({ userid }) => userid.toLowerCase().includes(valueTerm));
              break; 
          default:
              console.log('Default occured')
              break;      
        }
      
    }
  
    const rows = source.reduce(
      (acc, { vin, manufacturer, model, type, age, id, userid }) =>
        acc +
        `<tr>
          <td>${vin}</td>
          <td>${manufacturer}</td>
          <td>${model}</td>
          <td>${type}</td>
          <td>${age}</td>
          <td>${id}</td>
          <td>${userid}</td>
      </tr>`,
      ``
    );
  
    tableBody.innerHTML = rows;
  };
  
  loadData(`./data.example.json`).then((data) => renderTable(data));

  const onSubmit = (event) => {
    event.preventDefault();
  
    const term = event.target.filters.value;
    
    loadData(`./data.example.json`).then((data) => renderTable(data, term));
  };
  
  const onReset = () => {
    loadData(`./data.example.json`).then((data) => renderTable(data));
  };